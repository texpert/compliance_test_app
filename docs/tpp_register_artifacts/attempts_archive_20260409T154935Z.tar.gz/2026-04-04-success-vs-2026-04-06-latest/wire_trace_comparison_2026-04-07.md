# Wire Trace Comparison: Successful `200` vs Replay `400`

Compared files:
- Successful trace: `successful/tpp_register_retry_trace.txt`
- Replay trace: `replay_success_shape_2026-04-07/tpp_register_replay_trace.txt`

## Executive summary

The replay trace matches the successful trace on the broad request shape (`POST`, flat JSON payload, PEM-style `TPP-Signature-Certificate`, DN-style `keyId`, signed headers `digest date x-request-id`, `Accept: */*`, `Content-Type: application/json`).

However, there are still material differences visible in the wire traces:
- the certificate itself is different,
- the DN `keyId` value is different,
- the signature bytes are different,
- the reported `Content-Length` differs,
- and the backend now returns `400 Header 'Digest' invalid...` instead of `200`.

## Outbound request comparison

### Unchanged between successful and replay traces
- Request line: `POST /api/berlingroup/v1/tpp/register HTTP/1.1`
- Host: `priora.saltedge.com`
- User-Agent family: `curl/8.19.0`
- `Accept: */*`
- `Content-Type: application/json`
- `Digest` header **value**: `SHA-256=tPebFMB03olmURhEYvaKuHC0c+C2bchhX+0zBanArCE=`
- `Signature.headers`: `digest date x-request-id`
- `TPP-Signature-Certificate` starts with `LS0tLS1CRUdJTi...`, i.e. base64 of PEM text, not DER
- Body contract remains flat JSON: top-level `company`, `representative`, `certificate`

### Changed between successful and replay traces

| Aspect | Successful trace | Replay trace | Notes |
|---|---|---|---|
| `X-Request-ID` | `7dbb368a-577e-4bc6-8184-a2889927c11f` | `6b6f3729-f928-46e0-878a-36e4924aaf2b` | Expected per request |
| `Date` | `Sat, 04 Apr 2026 23:29:45 GMT` | `Mon, 06 Apr 2026 21:30:54 GMT` | Expected per request |
| DN `keyId` org identifier | `PSDMD-BNM-99999` | `PGB-123` | Material difference |
| `Signature.signature` value | Different base64 blob | Different base64 blob | Expected because date/request-id/keyId/cert changed |
| `TPP-Signature-Certificate` body | Different PEM certificate payload | Different PEM certificate payload | Material: not the same cert |
| `Content-Length` | `402` | `385` | Material / surprising given identical digest value |
| Response status | `200 OK` | `400 Bad Request` | Material |
| Response body | `{"message":"Request is processed..."}` | `{"tppMessages":[{"category":"ERROR","code":"REQUEST_FORMAT_INVALID","text":"Header 'Digest' invalid. Expected format: SHA-256={SHA256Base64(requestBody)}"}]}` | Material |

## Most important raw trace findings

### 1) The replay is on the old request-validation path, not the current malformed-signature path
Successful and replay traces both send:
- flat JSON payload,
- DN-style `keyId`,
- PEM-base64 `TPP-Signature-Certificate`,
- `headers="digest date x-request-id"`.

That means the replay is close enough to the historical contract to trigger the **digest-validation** branch rather than the newer **malformed-signature** branch.

### 2) The “successful” preserved trace is not the original attempt-2 `PGB-123` request
The successful trace itself shows:
- `keyId="SN=0,DN=/organizationIdentifier=PSDMD-BNM-99999/...`.

So this preserved `200` trace corresponds to a later successful `texpert-v2`-era submission path, not the original attempt-2 `guide_2026-04-04-texpert` submission with `organizationIdentifier=PGB-123`.

This is important because it explains why the replay, which now uses `guide_2026-04-04-texpert`, cannot be treated as a byte-identical reproduction of that preserved `200` trace.

### 3) The digest value is identical across both traces
Both traces send exactly:
- `Digest: SHA-256=tPebFMB03olmURhEYvaKuHC0c+C2bchhX+0zBanArCE=`

But the trace metadata reports different `Content-Length` values (`402` vs `385`).

Interpretation:
- either the payload bytes are effectively the same and curl trace formatting/visualization is misleading,
- or the preserved successful trace contains a body variant that still hashes to the same value only if the apparent formatting difference is not a true byte difference.

Conclusion: we should trust the **digest header value** more than the visual whitespace rendering in the trace ASCII dump.

### 4) The remaining wire-level delta is primarily certificate identity and derived signature material
Once the request shape is aligned, the biggest remaining request-side differences are:
- the actual PEM certificate sent in `TPP-Signature-Certificate`,
- the DN `keyId` value (`PSDMD-BNM-99999` vs `PGB-123`),
- the signature bytes derived from those values.

That means the replay is not a byte-for-byte copy of the preserved `200` trace even though the overall contract is the same.

## Inbound response comparison

### Successful trace response
- `HTTP/1.1 200 OK`
- body: `{"message":"Request is processed. We will send the response to branzeanu.aurel@gmail.com"}`

### Replay trace response
- `HTTP/1.1 400 Bad Request`
- body: `{"tppMessages":[{"category":"ERROR","code":"REQUEST_FORMAT_INVALID","text":"Header 'Digest' invalid. Expected format: SHA-256={SHA256Base64(requestBody)}"}]}`

## Interpretation

The trace comparison shows that we did successfully recover the old **request family** (not the new malformed-signature family), but we did **not** recreate the exact same certificate/signature identity as the preserved `200` trace.

So there are two credible takeaways:
1. the backend validation path has changed since the old `200` responses, **and/or**
2. the preserved successful trace belongs to a different cert generation (`PSDMD-BNM-99999` / `texpert-v2`) than the replayed `guide_2026-04-04-texpert` cert (`PGB-123`).

In other words: the replay is structurally faithful, but not certificate-identical to the preserved successful trace.
