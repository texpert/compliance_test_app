# One-Page Header and Params Diff (Successful vs Current)

Scope: request-side comparison for `POST /api/berlingroup/v1/tpp/register` using:
- successful wire trace: `successful/tpp_register_retry_trace.txt`
- successful script: `successful/tpp_register_retry_20260404.sh`
- current script: `latest/tpp_register_retry_current.sh`
- controlled replay wire trace: `replay_success_shape_2026-04-07/tpp_register_replay_trace.txt`

| Field | Successful (2026-04-04 trace/script) | Current (`latest/tpp_register_retry_current.sh`) | Controlled Replay (2026-04-07 trace) | Delta significance |
|---|---|---|---|---|
| HTTP method/path | `POST /api/berlingroup/v1/tpp/register` | Same | Same | No change |
| `Accept` | `*/*` (curl default) | `application/json` | `*/*` | Low |
| `Content-Type` | `application/json` | `application/json` | `application/json` | No change |
| Payload root shape | Flat: top-level `company`, `representative`, `certificate` | Wrapped under `data` | Flat | High |
| Certificate in JSON payload | No `certificate.value` | Includes `certificate.value` (base64 cert body) | No `certificate.value` | High |
| Payload byte length (trace) | `Content-Length: 402` | Dynamic (larger due to `certificate.value`) | `Content-Length: 385` | Medium (formatting/serialization influences digest) |
| `Digest` header format | `SHA-256=<base64>` | Same format | Same format | No structural change |
| Signed headers list (`Signature.headers`) | `digest date x-request-id` | `(request-target) date x-request-id digest` | `digest date x-request-id` | High |
| Canonical signing string | `digest`, `date`, `x-request-id` | Adds `(request-target)` and reorders with `digest` last | `digest`, `date`, `x-request-id` | High |
| `keyId` style | DN style: `SN=0,DN=/organizationIdentifier=.../CN=.../O=.../C=.../ST=...` | SHA-256 fingerprint (hex, lowercase, colonless) | DN style | High |
| `TPP-Signature-Certificate` encoding | Base64 of full PEM text (`LS0tLS1CRUdJTi...`) | Base64 of DER (`openssl x509 -outform der`) | Base64 of full PEM text (`LS0tLS1CRUdJTi...`) | High |
| `Signature` header prefix | `Signature: keyId=...,algorithm=...,headers=...,signature=...` | Same pattern | Same pattern | No change |
| `X-Request-ID` header | Present | Present | Present | No change |
| `Date` header | Present (RFC7231 style GMT) | Present (same format) | Present (same format) | No change |

## Result Context

| Scenario | HTTP result | Response text |
|---|---|---|
| Successful (2026-04-04) | `200` | `Request is processed...` |
| Current implementation path (latest retest) | `400` | `Header 'Signature' invalid: Malformed signature` |
| Controlled replay (old shape) | `400` | `Header 'Digest' invalid. Expected format: SHA-256={SHA256Base64(requestBody)}` |

## Evidence pointers
- Successful script logic: `successful/tpp_register_retry_20260404.sh`
- Successful outbound headers/body: `successful/tpp_register_retry_trace.txt`
- Current script logic: `latest/tpp_register_retry_current.sh`
- Current canonical string sample: `latest/tpp_register_signing_string.txt`
- Replay outbound headers/body: `replay_success_shape_2026-04-07/tpp_register_replay_trace.txt`
- Replay response: `replay_success_shape_2026-04-07/tpp_register_replay_response.json`

## Interpretation
- Request contract drift exists across four high-impact fields: payload shape, signed-headers canonicalization, `keyId` format, and certificate header encoding.
- Replaying the old successful contract no longer restores `HTTP 200`; current backend behavior still rejects, but on a different validator (`Digest`) path.
- Net: evidence favors backend-side validation-path change/regression over a single isolated client typo.
