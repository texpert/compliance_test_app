#!/usr/bin/env bash
set -euo pipefail
set -a
source "/Users/Shared/dev/Salt Edge/compliance_test_app/.env"
set +a
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT
BODY=$(jq -n \
  --arg city "$SE_TPP_COMPANY_CITY" \
  --arg address "$SE_TPP_COMPANY_ADDRESS" \
  --arg email "$SE_TPP_COMPANY_EMAIL" \
  --arg name "$SE_TPP_COMPANY_NAME" \
  --arg phone "$SE_TPP_COMPANY_PHONE_NUMBER" \
  --arg zip "$SE_TPP_COMPANY_ZIP_CODE" \
  --arg rep_email "$SE_TPP_REPRESENTATIVE_EMAIL" \
  --arg rep_name "$SE_TPP_REPRESENTATIVE_NAME" \
  --arg cert_name "$SE_TPP_CERTIFICATE_NAME" \
  --arg cert_type "$SE_TPP_CERTIFICATE_TYPE" \
  '{company:{city:$city,address:$address,email:$email,name:$name,phone_number:$phone,zip_code:$zip},representative:{email:$rep_email,name:$rep_name},certificate:{name:$cert_name,type:$cert_type}}')
printf '%s' "$BODY" > "$TMP_DIR/body.json"
X_REQUEST_ID=$(uuidgen | tr '[:upper:]' '[:lower:]')
DATE_HDR=$(LC_ALL=C date -u "+%a, %d %b %Y %H:%M:%S GMT")
openssl dgst -sha256 -binary -out "$TMP_DIR/digest.bin" "$TMP_DIR/body.json"
base64 -b 0 < "$TMP_DIR/digest.bin" > "$TMP_DIR/digest.b64"
DIGEST_HDR="SHA-256=$(cat "$TMP_DIR/digest.b64")"
base64 -b 0 < "$SE_QSEAL_CERT_PATH" > "$TMP_DIR/cert.b64"
CERT_B64=$(cat "$TMP_DIR/cert.b64")
KEY_ID="SN=0,DN=/organizationIdentifier=$SE_QSEAL_SUBJECT_ORGANIZATION_IDENTIFIER/CN=$SE_QSEAL_SUBJECT_CN/O=$SE_QSEAL_SUBJECT_O/C=$SE_QSEAL_SUBJECT_C/ST=$SE_QSEAL_SUBJECT_ST"
printf 'digest: %s\ndate: %s\nx-request-id: %s' "$DIGEST_HDR" "$DATE_HDR" "$X_REQUEST_ID" > "$TMP_DIR/signing_string.txt"
openssl dgst -sha256 -sign "$SE_QSEAL_KEY_PATH" -out "$TMP_DIR/signature.bin" "$TMP_DIR/signing_string.txt"
base64 -b 0 < "$TMP_DIR/signature.bin" > "$TMP_DIR/signature.b64"
SIGNATURE_B64=$(cat "$TMP_DIR/signature.b64")
SIGNATURE_HDR="keyId=\"$KEY_ID\",algorithm=\"rsa-sha256\",headers=\"digest date x-request-id\",signature=\"$SIGNATURE_B64\""
curl --trace-time --trace-ascii /tmp/tpp_register_retry_trace.txt -sS \
  -o /tmp/tpp_register_retry_response.json \
  -w "HTTP_STATUS:%{http_code}\n" \
  -X POST "$SE_API_BASE_URL/api/berlingroup/v1/tpp/register" \
  -H "X-Request-ID: $X_REQUEST_ID" \
  -H "Digest: $DIGEST_HDR" \
  -H "Date: $DATE_HDR" \
  -H "TPP-Signature-Certificate: $CERT_B64" \
  -H "Signature: $SIGNATURE_HDR" \
  -H "Content-Type: application/json" \
  -d "$BODY"
echo "--- response body ---"
cat /tmp/tpp_register_retry_response.json
